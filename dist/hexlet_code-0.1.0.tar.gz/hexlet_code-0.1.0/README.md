### Hexlet tests and linter status:
[![Actions Status](https://github.com/D4rkli/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/D4rkli/python-project-49/actions)
<a href="https://codeclimate.com/github/D4rkli/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0f319a9781c1f9341917/maintainability" /></a>
## Демонстрация установки и запуска игры
[![asciicast](https://asciinema.org/a/LyTIyFK02TPwz7B8EThR4ItaL)](https://asciinema.org/a/LyTIyFK02TPwz7B8EThR4ItaL)

[![asciicast](https://asciinema.org/a/cJIzzqMD13GeUgRL73TtsqXlS)]
